#!/usr/bin/env bash
set -euo pipefail
# Requires GitHub CLI and git, with git user.name/email configured. No API tokens stored.
ROOT="$(cd "$(dirname "$0")" && pwd)"
OWNER=''
MODE='--dry-run'
while (( $# )); do
  case "$1" in
    --owner) OWNER="${2:?Missing account login}"; shift 2 ;;
    --apply) MODE='--apply'; shift ;;
    --dry-run) MODE='--dry-run'; shift ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
done
[[ -n "$OWNER" ]] || { echo 'Usage: bash publish_private_repos.sh --owner YOUR_GITHUB_LOGIN [--dry-run|--apply]' >&2; exit 2; }
command -v gh >/dev/null || { echo 'GitHub CLI (gh) not installed. Install and run gh auth login.' >&2; exit 2; }
command -v git >/dev/null || { echo 'git not installed' >&2; exit 2; }
ACTIVE="$(gh api user --jq .login)"
[[ "$ACTIVE" == "$OWNER" ]] || { echo "Account mismatch: active '$ACTIVE', requested '$OWNER'. Run gh auth switch." >&2; exit 2; }
REPOS=(forgeworks-apishield-agent forgeworks-accessfix-ai forgeworks-specforge-ai forgeworks-agenttest-lab forgeworks-datareconcile-ai)
for name in "${REPOS[@]}"; do
  [[ -f "$ROOT/$name/contracts/openapi.yaml" ]] || { echo "Missing source $name" >&2; exit 2; }
  if gh repo view "$OWNER/$name" --json name --jq .name >/dev/null 2>&1; then
    echo "Existing repo: $OWNER/$name. Refusing to overwrite." >&2; exit 2
  fi
done
printf 'Active GitHub account: %s\n' "$ACTIVE"
printf 'Visibility: PRIVATE for all 5 repos\n'
if [[ "$MODE" == '--dry-run' ]]; then
  printf 'Dry-run only. Would create:\n'
  for name in "${REPOS[@]}"; do printf '  %s/%s\n' "$OWNER" "$name"; done
  echo 'To publish after review: bash publish_private_repos.sh --owner YOUR_GITHUB_LOGIN --apply'
  exit 0
fi
[[ -n "$(git config --global user.name || true)" && -n "$(git config --global user.email || true)" ]] || {
  echo 'Set git config --global user.name and user.email before publishing.' >&2; exit 2;
}
for name in "${REPOS[@]}"; do
  d="$ROOT/$name"
  (cd "$d"
   for check in verify_bootstrap.py verify_contracts.py validate_openapi_independent.py; do
     python "scripts/$check"
   done
   if [[ ! -d .git ]]; then git init -b main; fi
   [[ "$(git branch --show-current)" == main ]] || { echo 'Expected main branch' >&2; exit 2; }
   printf '* @%s\n' "$OWNER" > .github/CODEOWNERS
   git add .
   if ! git diff --cached --quiet; then git commit -m 'docs: bootstrap G1 design and verification scaffolding'; fi
   git rev-parse --verify HEAD >/dev/null
   gh repo create "$OWNER/$name" --private --source . --remote origin --push)
  echo "Created private repository: https://github.com/$OWNER/$name"
done
