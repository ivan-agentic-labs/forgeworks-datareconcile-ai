# ForgeWorks AI — G2 GitHub Bootstrap (2026-10-09)

## Included
Exactly five independent repository folders. **No sixth repository**. All are design and verification scaffolds, not working AI products. Source documents were copied from the G1 consolidated final-candidate baseline.

## GitHub account selection
The owner selected `ivan-agentic-labs`, and the connected account login was verified. Remote repository creation and push are pending because the available GitHub connector does not expose repository creation. No remote success is claimed.

## Run on your terminal
1. Install Git and GitHub CLI (`gh`). Sign into the one account you want.
2. Run `gh auth status` and `gh api user --jq .login`.
3. Unzip the archive, enter this directory, review files.
4. `bash publish_private_repos.sh --owner ivan-agentic-labs --dry-run`
5. `bash publish_private_repos.sh --owner ivan-agentic-labs --apply`

The script refuses to overwrite existing repos and checks account matching. It creates **private** repositories and pushes an initial commit under **your** Git identity. The script does not deploy, install paid services or add real credentials. If a push partially fails, investigate before retrying; do not delete existing repos casually.

## G1 state
Owner design direction approved for bootstrap. G1-E remains pending: independent OpenAPI validation, PostgreSQL live RLS and concurrency testing, identity provisioning, sandbox isolation, domain/operational decisions. Candidate SQL stays in `docs/verification/sql-candidates/`, never `migrations/versions/`.

## After publishing
Inspect Actions for each repo. `G1 Contract Verification` runs on the initial push; contract problems must be fixed, not suppressed. Run `G1 Disposable PostgreSQL DDL Proof` manually; even a green DDL smoke test is not proof of tenant RLS/security. Do not enable external agent execution until further verified gates.
