# ForgeWorks AI — Consolidated G1 Design Candidate

**Date:** 2026-10-09. **Products:** APIShield Agent, AccessFix AI, SpecForge AI, AgentTest Lab, DataReconcile AI.

This is the **single current pre-implementation handoff candidate**, consolidating five product-specific designs, typed OpenAPI/event contracts, SQL candidates, proposed composite FKs, security and operations decisions, tests, and an evidence status matrix. It does **not** assert fully approved design, validated PostgreSQL, deployed application, production security, or customer acceptance. No GitHub repository or application code is created.

Read in order: `MASTER_G1_DECISION.md`, `shared/08_OWNER_DECISION_REGISTER.md`, `shared/09_POLICY_DECISION_ADDENDUM.md`, then each `products/<slug>/DESIGN_GATE_STATUS.md` and the product-specific contracts and data files. Do not use historical ZIPs as implementation authority if they conflict with this candidate.

`verification/offline_verify.py` independently reruns **limited static** consistency checks. `verification/POSTGRESQL_LIVE_PROOF.md` lists commands and assertions that MUST run in a disposable real PostgreSQL server before G1-E is signed. `verification/OPENAPI_EXTERNAL_PROOF.md` specifies independent conformance and client compilation.

**Design evidence vs runtime proof are separate**. `PASS_STATIC_LIMITED` is not `PASS_G1`.
